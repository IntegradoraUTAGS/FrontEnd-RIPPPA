export class AdministradorModel {
    _id?: string;
    idRol: string;
    idDireccion: string;
    strNombre: string;
    numCodigoEmpleado: number;
    strContrasenia: string;
}