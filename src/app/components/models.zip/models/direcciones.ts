export class DireccionesModel {

    strNombre: string;
    blnEstado: boolean;
}